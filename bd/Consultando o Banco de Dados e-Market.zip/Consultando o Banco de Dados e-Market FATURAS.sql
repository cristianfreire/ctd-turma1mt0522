-- 1) Obtenha uma lista de todas as faturas, ordenadas por data da fatura em ordem ascendente.
SELECT * FROM FATURAS ORDER BY DATAFATURA ASC;

-- 2) Agora é necessário uma lista de faturas com o país de envio "EUA" e
-- que a FormaeEnvio seja diferente de 3.
SELECT *
FROM faturas
WHERE PAISENVIO = 'USA' AND FormaEnvio != 3;

-- 3) O cliente 'GOURL' fez um pedido? Sim.
SELECT * FROM FATURAS where CLIENTEID = 'GOURL';

-- 4) Você deseja visualizar todas as faturas dos funcionários 2, 3, 5, 8 e 9.
SELECT * FROM FATURAS WHERE EMPREGADOID >= 2 AND EMPREGADOID <= 9;

-- 	DETALHEFATURA
-- 1) Obtenha uma lista de FaturaId, Produto, Quantidade.
SELECT FATURAID, PRODUTOID, QUANTIDADE FROM DETALHEFATURA; 

-- 2) Classifique a lista acima por Quantidade decrescente. 
SELECT FATURAID, PRODUTOID, QUANTIDADE FROM DETALHEFATURA ORDER BY QUANTIDADE ASC; 

-- 3) Filtre a mesma lista apenas para os produtos cuja quantidade esteja entre 50 e 100. 
SELECT FATURAID, PRODUTOID, QUANTIDADE 
FROM DETALHEFATURA 
WHERE QUANTIDADE BETWEEN 50 AND 100
ORDER BY QUANTIDADE ASC ; 


