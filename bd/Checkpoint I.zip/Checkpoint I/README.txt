Uma escola precisa de um banco de dados para armazenar os Alunos, com nome, matricula
email, endereco e telefone.
Cada aluno tem uma turma representada por um curso, 
Um curso pode ter várias disciplinas e cada disciplina tem 1 professor.
Professor possui nome, matricula, email, endereco e telefone.